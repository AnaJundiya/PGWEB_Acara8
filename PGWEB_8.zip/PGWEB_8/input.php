<?php
$kecamatan = isset($_POST['kecamatan']) ?$_POST['kecamatan'] : null;
$luas = isset($_POST['luas']) ? $_POST['luas'] : null;
$jumlah_penduduk = isset($_POST['jumlah_penduduk']) ? $_POST['jumlah_penduduk'] : null;

// Check if all required fields are available
if ($kecamatan && $luas && $jumlah_penduduk) {
    // Sesuaikan dengan setting MySQL
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "pgweb_acara8";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and bind SQL statement to prevent SQL injection
    $stmt = $conn->prepare("INSERT INTO penduduk (kecamatan, luas, jumlah_penduduk) VALUES (?, ?, ?)");
    $stmt->bind_param("sii", $kecamatan, $luas, $jumlah_penduduk); // s = string, i = integer

    // Execute the statement
    if ($stmt->execute()) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo "Error: All fields are required.";
}
?>
